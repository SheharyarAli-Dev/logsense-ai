from collections import Counter, defaultdict
from datetime import datetime, timedelta


IMPORTANCE = {
    "Crash Issue": 3,
    "Memory Issue": 2,
    "Disk Issue": 2,
    "Network Issue": 2,
    "General Error": 1
}


def determine_root_cause(issue_count: dict) -> str:
    if not issue_count:
        return "No Major Issue"
    weighted = {issue: count * IMPORTANCE.get(issue, 1) for issue, count in issue_count.items()}
    return max(weighted, key=weighted.get)


def calculate_severity(issue_count: dict) -> str:
    total = sum(issue_count.values())
    if issue_count.get("Crash Issue", 0) > 0:
        return "Critical"
    if issue_count.get("Memory Issue", 0) >= 2:
        return "High"
    if total >= 3:
        return "Medium"
    return "Low"


def analyze_root_cause(logs: list) -> dict:
    categories = [log["category"] for log in logs if log["category"] != "Normal"]
    if not categories:
        return {"root_cause": "No major issues detected", "severity": "Low", "issue_count": {}}
    issue_count = dict(Counter(categories))
    return {
        "root_cause": determine_root_cause(issue_count),
        "severity": calculate_severity(issue_count),
        "issue_count": issue_count
    }


def analyze_trends(logs: list, interval_minutes: int = 10) -> dict:
    timeline = defaultdict(lambda: defaultdict(int))
    for log in logs:
        ts = datetime.strptime(log["timestamp"], "%Y-%m-%d %H:%M:%S")
        bucket = ts - timedelta(
            minutes=ts.minute % interval_minutes,
            seconds=ts.second,
            microseconds=ts.microsecond
        )
        timeline[bucket][log["category"]] += 1
    return {str(k): dict(v) for k, v in sorted(timeline.items())}
