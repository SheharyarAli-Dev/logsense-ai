SOLUTIONS = {
    "Memory Issue": [
        "Check for memory leaks in the application",
        "Increase available system RAM",
        "Restart memory-intensive services",
    ],
    "Disk Issue": [          # Fixed: was "Storage Issue" — now matches classifier output
        "Clean up disk space and remove old log files",
        "Check log rotation configuration",
        "Expand storage volume or add a new disk",
    ],
    "Network Issue": [
        "Check server connectivity and DNS resolution",
        "Verify firewall rules and open ports",
        "Inspect network latency and packet loss",
    ],
    "Crash Issue": [
        "Inspect application crash logs for stack traces",
        "Restart the affected service",
        "Review recent code deployments or config changes",
    ],
    "General Error": [
        "Review error logs in detail",
        "Check application configuration files",
    ],
}


def suggest_solution(root_cause: str) -> list:
    return SOLUTIONS.get(root_cause, ["No specific suggestion available — review logs manually."])
